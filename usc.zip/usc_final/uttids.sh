#!/bin/bash

cp ~/Downloads/usc/filesets/validation.txt ./data/dev/uttids
cp ~/Downloads/usc/filesets/testing.txt ./data/test/uttids
cp ~/Downloads/usc/filesets/training.txt ./data/train/uttids
