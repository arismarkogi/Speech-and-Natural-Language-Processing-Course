#!/bin/bash

source path.sh

~/kaldi/egs/usc/utils/prepare_lang.sh ~/kaldi/egs/usc/data/local/dict/ '<oov>' ~/kaldi/egs/usc/local/tmp ./data/lang
